<?php

return [
    'ghl_token'              => 'pit-195d44e7-6b55-4e86-aa33-1c039d458e5c',
    'ghl_location_id'        => 'aLTXtdwNknfmEFo3WBIX',
    'upload_shared_secret'   => 'WsP0DZcLrHRHC9wA3I2Ex2q1hZ/g0W26N+vJ1S3hSei3pusOlI2CaS7zOOG9iKPn',
    'upload_max_mb'          => 10,
    'upload_allowed_origins' => [
        'https://cheapalarms.com.au',
        'https://staging.cheapalarms.com.au',
        'http://localhost',
        'http://localhost:3000',
        'http://localhost:5173',
        'http://127.0.0.1:5173',
    ],
];


<?php

namespace CheapAlarms\Plugin;

use CheapAlarms\Plugin\Admin\Menu;
use CheapAlarms\Plugin\Config\Config;
use CheapAlarms\Plugin\Frontend\PortalPage;
use CheapAlarms\Plugin\REST\ApiKernel;
use CheapAlarms\Plugin\REST\Auth\Authenticator;
use CheapAlarms\Plugin\Services\Container;
use CheapAlarms\Plugin\Services\Logger;

class Plugin
{
    private static ?Plugin $instance = null;

    private Container $container;

    private function __construct()
    {
        $this->container = new Container();
    }

    public static function instance(): Plugin
    {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function boot(): void
    {
        add_action('init', [$this, 'bootstrap']);
    }

    public function bootstrap(): void
    {
        if (function_exists('error_log')) {
            error_log('[CheapAlarms Plugin] bootstrap executing');
        }
        $this->registerServices();
        $this->registerRestEndpoints();
        $this->registerFrontend();
        $this->registerAdminUi();
    }

    private function registerServices(): void
    {
        $this->container->set(Config::class, fn () => new Config());
        $this->container->set(Logger::class, fn () => new Logger());
        $this->container->set(Authenticator::class, fn () => new Authenticator($this->container->get(Config::class)));
        $this->container->set(\CheapAlarms\Plugin\Services\GhlClient::class, fn () => new \CheapAlarms\Plugin\Services\GhlClient(
            $this->container->get(Config::class),
            $this->container->get(Logger::class)
        ));
        $this->container->set(\CheapAlarms\Plugin\Services\EstimateService::class, fn () => new \CheapAlarms\Plugin\Services\EstimateService(
            $this->container->get(Config::class),
            $this->container->get(\CheapAlarms\Plugin\Services\GhlClient::class),
            $this->container->get(Logger::class)
        ));
        $this->container->set(\CheapAlarms\Plugin\Services\UploadService::class, fn () => new \CheapAlarms\Plugin\Services\UploadService(
            $this->container->get(Config::class),
            $this->container->get(\CheapAlarms\Plugin\Services\EstimateService::class),
            $this->container->get(Logger::class)
        ));
        $this->container->set(\CheapAlarms\Plugin\Services\PortalService::class, fn () => new \CheapAlarms\Plugin\Services\PortalService(
            $this->container->get(\CheapAlarms\Plugin\Services\EstimateService::class),
            $this->container->get(Logger::class)
        ));
    }

    private function registerRestEndpoints(): void
    {
        add_action('rest_api_init', function () {
            if (function_exists('error_log')) {
                error_log('[CheapAlarms Plugin] rest_api_init register controllers');
            }
            $kernel = new ApiKernel($this->container);
            $kernel->register();
        });
    }

    private function registerAdminUi(): void
    {
        new Menu();
    }

    private function registerFrontend(): void
    {
        new PortalPage();
    }

    public function container(): Container
    {
        return $this->container;
    }

    public function activate(): void
    {
        PortalPage::activate();
        flush_rewrite_rules();
    }
}


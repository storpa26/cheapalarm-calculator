<?php

namespace CheapAlarms\Plugin\REST\Controllers;

interface ControllerInterface
{
    public function register(): void;
}


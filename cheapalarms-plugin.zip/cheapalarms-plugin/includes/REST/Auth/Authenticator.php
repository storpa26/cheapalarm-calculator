<?php

namespace CheapAlarms\Plugin\REST\Auth;

use CheapAlarms\Plugin\Config\Config;
use WP_Error;
use WP_REST_Request;

class Authenticator
{
    public function __construct(private Config $config)
    {
    }

    public function ensureConfigured(): void
    {
        if (!$this->config->isConfigured()) {
            wp_die(__('CheapAlarms plugin is not configured. Please set CA_GHL_TOKEN and CA_LOCATION_ID.', 'cheapalarms'), '', 500);
        }
    }

    public function requireAdmin(): bool|WP_Error
    {
        if (!current_user_can('manage_options')) {
            return new WP_Error('forbidden', __('Administrator privileges required.', 'cheapalarms'), ['status' => 403]);
        }
        return true;
    }

    public function publicAllowed(): bool
    {
        // For public endpoints we still ensure plugin configured
        return true;
    }

    public function validateNonce(WP_REST_Request $request, string $action = 'ca_portal'): bool|WP_Error
    {
        $nonce = $request->get_header('X-WP-Nonce') ?: $request->get_param('_wpnonce');
        if ($nonce && wp_verify_nonce($nonce, $action)) {
            return true;
        }
        return new WP_Error('invalid_nonce', __('Invalid security token.', 'cheapalarms'), ['status' => 403]);
    }
}


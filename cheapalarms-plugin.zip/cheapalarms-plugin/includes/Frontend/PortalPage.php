<?php

namespace CheapAlarms\Plugin\Frontend;

use function add_rewrite_rule;
use function esc_html__;
use function get_query_var;
use function get_stylesheet_directory;
use function get_stylesheet_directory_uri;
use function home_url;
use function sanitize_text_field;
use function status_header;
use function file_exists;
use function file_get_contents;
use function json_decode;
use function wp_die;
use function wp_unslash;

class PortalPage
{
    private const QUERY_VAR = 'cheapalarms_portal';

    private static array $viewData = [];

    private ?array $manifest = null;
    private string $assetBase = '';

    public static function getViewData(): array
    {
        return self::$viewData;
    }

    public static function activate(): void
    {
        add_rewrite_rule('^portal/?$', 'index.php?' . self::QUERY_VAR . '=1', 'top');
    }

    public function __construct()
    {
        add_action('init', [$this, 'registerRewrite']);
        add_filter('query_vars', [$this, 'registerQueryVar']);
        add_filter('template_include', [$this, 'maybeInterceptTemplate']);
    }

    public function registerRewrite(): void
    {
        add_rewrite_rule('^portal/?$', 'index.php?' . self::QUERY_VAR . '=1', 'top');
    }

    public function registerQueryVar(array $vars): array
    {
        if (!in_array(self::QUERY_VAR, $vars, true)) {
            $vars[] = self::QUERY_VAR;
        }
        return $vars;
    }

    public function maybeInterceptTemplate(string $template): string
    {
        if (!get_query_var(self::QUERY_VAR)) {
            return $template;
        }

        $viewData = $this->prepareViewData();
        if (!$viewData) {
            return $template;
        }

        self::$viewData = $viewData;
        status_header(200);
        return CA_PLUGIN_PATH . 'views/portal-app.php';
    }

    private function prepareViewData(): ?array
    {
        $entry = $this->getManifestEntry();
        if (!$entry) {
            wp_die(
                esc_html__('CheapAlarms portal assets are missing. Build the React app and deploy assets to the theme `react-app` directory.', 'cheapalarms'),
                esc_html__('Portal unavailable', 'cheapalarms'),
                ['response' => 500]
            );
            return null;
        }

        $estimateId = isset($_GET['estimateId']) ? sanitize_text_field(wp_unslash($_GET['estimateId'])) : '';
        $locationId = isset($_GET['locationId']) ? sanitize_text_field(wp_unslash($_GET['locationId'])) : '';
        $inviteToken = isset($_GET['inviteToken']) ? sanitize_text_field(wp_unslash($_GET['inviteToken'])) : '';

        $config = [
            'estimateId' => $estimateId,
            'locationId' => $locationId,
            'inviteToken' => $inviteToken,
            'apiBase'    => home_url(),
        ];

        return [
            'assetBase'    => $this->assetBase,
            'mainJs'       => $entry['file'],
            'mainCss'      => $entry['css'][0] ?? null,
            'portalConfig' => $config,
        ];
    }

    private function getManifestEntry(): ?array
    {
        $manifest = $this->loadManifest();
        if (!$manifest) {
            return null;
        }

        return $manifest['src/main.jsx'] ?? null;
    }

    private function loadManifest(): ?array
    {
        if ($this->manifest !== null) {
            return $this->manifest;
        }

        $themeDir = get_stylesheet_directory();
        $reactDir = $themeDir . '/react-app';
        $manifestPath = $reactDir . '/.vite/manifest.json';

        if (!file_exists($manifestPath)) {
            return $this->manifest = null;
        }

        $decoded = json_decode(file_get_contents($manifestPath), true);
        if (!is_array($decoded)) {
            return $this->manifest = null;
        }

        $this->assetBase = get_stylesheet_directory_uri() . '/react-app';
        $this->manifest = $decoded;

        return $this->manifest;
    }
}


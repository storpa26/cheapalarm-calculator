<?php

namespace CheapAlarms\Plugin\Services;

use WP_Error;
use WP_User;

use function add_query_arg;
use function apply_filters;
use function current_time;
use function __;
use function esc_html;
use function esc_url;
use function email_exists;
use function get_option;
use function get_user_meta;
use function get_password_reset_key;
use function get_user_by;
use function home_url;
use function is_wp_error;
use function sanitize_email;
use function sanitize_text_field;
use function update_option;
use function update_user_meta;
use function user_can;
use function wp_create_user;
use function wp_generate_password;
use function wp_mail;
use function wp_login_url;
use function wp_update_user;

class PortalService
{
    private const OPTION_PREFIX = 'ca_portal_meta_';

    public function __construct(
        private EstimateService $estimateService,
        private Logger $logger
    ) {
    }

    public function getDashboardData(\WP_User $user): array
    {
        if (!$user || 0 === $user->ID) {
            return ['estimates' => []];
        }

        $raw = $this->getDashboardForUser((int) $user->ID);
        $estimates = [];

        foreach ($raw as $item) {
            $estimates[] = [
                'estimateId'   => $item['estimateId'] ?? null,
                'locationId'   => $item['locationId'] ?? null,
                'status'       => $item['quote']['status'] ?? 'pending',
                'statusLabel'  => $item['quote']['statusLabel'] ?? 'Pending',
                'number'       => $item['quote']['number'] ?? ($item['estimateId'] ?? null),
                'acceptedAt'   => $item['quote']['acceptedAt'] ?? null,
                'portalUrl'    => $item['account']['portalUrl'] ?? null,
                'resetUrl'     => $item['account']['resetUrl'] ?? null,
                'lastInviteAt' => $item['account']['lastInviteAt'] ?? null,
            ];
        }

        return [
            'estimates' => $estimates,
        ];
    }

    private function generateToken(): string
    {
        return wp_generate_password(48, false, false);
    }

    private function resolvePortalUrl(string $estimateId, ?string $token = null): string
    {
        $base = apply_filters('cheapalarms_portal_base_url', home_url('/portal'));
        $args = ['estimateId' => $estimateId];
        if ($token) {
            $args['inviteToken'] = $token;
        }

        return add_query_arg($args, $base);
    }

    /**
     * @return array|WP_Error
     */
    public function getStatus(string $estimateId, string $locationId, ?string $inviteToken = null, ?WP_User $user = null)
    {
        $meta = $this->getMeta($estimateId);

        if ($inviteToken && !$this->validateInviteToken($estimateId, $inviteToken)) {
            return new WP_Error('invalid_invite', __('The invite link is no longer valid.', 'cheapalarms'), ['status' => 403]);
        }

        $effectiveLocation = $locationId ?: ($meta['locationId'] ?? '');

        if ($user instanceof WP_User && $user->ID > 0 && !$inviteToken && !user_can($user, 'manage_options')) {
            $linked = get_user_meta($user->ID, 'ca_estimate_ids', true);
            if (!is_array($linked)) {
                $linked = array_filter([$linked]);
            }
            if (!in_array($estimateId, $linked, true)) {
                return new WP_Error(
                    'forbidden_estimate',
                    __('This estimate is not linked to your account.', 'cheapalarms'),
                    ['status' => 403]
                );
            }

            if (!$effectiveLocation) {
                $locations = get_user_meta($user->ID, 'ca_estimate_locations', true);
                if (is_array($locations) && isset($locations[$estimateId])) {
                    $effectiveLocation = $locations[$estimateId];
                }
            }
        }

        $estimate = $this->estimateService->getEstimate([
            'estimateId' => $estimateId,
            'locationId' => $effectiveLocation,
        ]);
        if (is_wp_error($estimate)) {
            return $estimate;
        }

        if ($effectiveLocation) {
            $meta['locationId'] = $effectiveLocation;
            $this->updateMeta($estimateId, ['locationId' => $effectiveLocation]);
        }
        $locationId = $effectiveLocation;

        $estimateStatus = $estimate['status'] ?? '';
        $isAccepted     = $estimateStatus === 'accepted';

        $quoteStatus = [
            'status'      => $isAccepted ? 'accepted' : 'pending',
            'statusLabel' => $isAccepted ? 'Accepted via GHL' : 'Awaiting approval',
            'number'      => $estimate['estimateNumber'] ?? $estimate['estimateId'],
            'acceptedAt'  => $meta['quote']['acceptedAt'] ?? null,
            'canAccept'   => false,
        ];
        if ($isAccepted && empty($quoteStatus['acceptedAt'])) {
            $quoteStatus['acceptedAt'] = current_time('mysql');
        }

        $this->updateMeta($estimateId, ['quote' => $quoteStatus]);
        $meta = $this->getMeta($estimateId);

        $defaultAccount = [
            'status'      => 'pending',
            'statusLabel' => 'Invite pending',
            'lastInviteAt'=> null,
            'canResend'   => true,
            'portalUrl'   => null,
            'inviteToken' => null,
            'expiresAt'   => null,
            'userId'      => null,
            'resetUrl'    => null,
        ];

        $accountMeta = array_merge($defaultAccount, $meta['account'] ?? []);

        if ($isAccepted && ($accountMeta['status'] ?? '') !== 'active') {
            $provisioned = $this->provisionAccount($estimateId, $estimate['contact'] ?? [], $locationId);
            if (!is_wp_error($provisioned)) {
                $meta        = $this->getMeta($estimateId);
                $accountMeta = array_merge($defaultAccount, $meta['account'] ?? []);
            } else {
                $this->logger->error('Failed to auto-provision portal account', [
                    'estimateId' => $estimateId,
                    'error'      => $provisioned->get_error_message(),
                ]);
            }
        }

        return [
            'quote'        => $quoteStatus,
            'photos'       => $meta['photos'] ?? ['total' => 0, 'required' => 6, 'missingCount' => 6, 'items' => []],
            'installation' => $meta['installation'] ?? ['status' => 'pending', 'statusLabel' => 'Not scheduled', 'message' => null, 'canSchedule' => $quoteStatus['status'] === 'accepted'],
            'documents'    => $meta['documents'] ?? [],
            'account'      => $accountMeta,
        ];
    }

    /**
     * @return array|WP_Error
     */
    public function acceptEstimate(string $estimateId, string $locationId)
    {
        $status = [
            'status'      => 'accepted',
            'statusLabel' => 'Accepted',
            'acceptedAt'  => current_time('mysql'),
            'canAccept'   => false,
        ];

        $this->updateMeta($estimateId, ['quote' => $status]);

        return ['ok' => true, 'quote' => $status];
    }

    /**
     * @return array|WP_Error
     */
    public function provisionAccount(string $estimateId, array $contact, ?string $locationId = null)
    {
        $email = sanitize_email($contact['email'] ?? '');
        if (!$email) {
            return new WP_Error('missing_contact', __('Contact email is required to create an account.', 'cheapalarms'), ['status' => 400]);
        }

        $firstName = sanitize_text_field($contact['firstName'] ?? $contact['name'] ?? '');
        $lastName  = sanitize_text_field($contact['lastName'] ?? '');

        $userId = email_exists($email);
        $password = null;
        if (!$userId) {
            $password = wp_generate_password(20);
            $userId = wp_create_user($email, $password, $email);
            if (is_wp_error($userId)) {
                return $userId;
            }
            wp_update_user([
                'ID'         => $userId,
                'first_name' => $firstName,
                'last_name'  => $lastName,
            ]);
        }

        wp_update_user(['ID' => $userId, 'role' => 'customer']);
        $this->attachEstimateToUser((int) $userId, $estimateId, $locationId);

        $token     = $this->generateToken();
        $expiresAt = current_time('timestamp') + DAY_IN_SECONDS * 7;
        $portalUrl = $this->resolvePortalUrl($estimateId, $token);

        $accountMeta = [
            'status'      => 'active',
            'statusLabel' => 'Account active',
            'lastInviteAt'=> current_time('mysql'),
            'canResend'   => true,
            'portalUrl'   => $portalUrl,
            'inviteToken' => $token,
            'expiresAt'   => gmdate('c', $expiresAt),
            'userId'      => (int) $userId,
            'locationId'  => $locationId,
        ];

        $update = ['account' => $accountMeta];
        if ($locationId) {
            $update['locationId'] = $locationId;
        }
        $this->updateMeta($estimateId, $update);

        $displayName = sanitize_text_field($firstName ?: ($contact['name'] ?? 'customer'));

        $resetUrl = $this->sendPortalInvite(
            $email,
            $displayName,
            $portalUrl,
            (int) $userId,
            false
        );

        if ($resetUrl) {
            $accountMeta['resetUrl'] = $resetUrl;
            $this->updateMeta($estimateId, ['account' => $accountMeta]);
        }

        $this->logger->info('Portal account provisioned', [
            'estimateId' => $estimateId,
            'userId'     => $userId,
            'resetUrl'   => $resetUrl,
        ]);

        return [
            'ok'      => true,
            'userId'  => $userId,
            'account' => $accountMeta,
        ];
    }

    /**
     * @return array|WP_Error
     */
    public function resendInvite(string $estimateId, array $contact)
    {
        $email = sanitize_email($contact['email'] ?? '');
        if (!$email) {
            return new WP_Error('missing_contact', __('Contact email is required to resend invite.', 'cheapalarms'), ['status' => 400]);
        }

        $currentMeta = $this->getMeta($estimateId)['account'] ?? [];
        $token       = $currentMeta['inviteToken'] ?? $this->generateToken();
        $portalLink  = $this->resolvePortalUrl($estimateId, $token);

        $userId      = isset($currentMeta['userId']) ? (int) $currentMeta['userId'] : (int) email_exists($email);
        $contactName = sanitize_text_field($contact['name'] ?? $contact['firstName'] ?? 'customer');

        $resetUrl = $this->sendPortalInvite(
            $email,
            $contactName,
            $portalLink,
            $userId,
            true
        );

        $this->updateMeta($estimateId, [
            'account' => array_merge($currentMeta, [
                'lastInviteAt' => current_time('mysql'),
                'status'       => $currentMeta['status'] ?? 'pending',
                'statusLabel'  => ($currentMeta['status'] ?? '') === 'active' ? 'Account active' : 'Invite sent',
                'canResend'    => true,
                'inviteToken'  => $token,
                'portalUrl'    => $portalLink,
                'expiresAt'    => gmdate('c', current_time('timestamp') + DAY_IN_SECONDS * 7),
                'userId'       => $userId ?: ($currentMeta['userId'] ?? null),
                'resetUrl'     => $resetUrl ?: ($currentMeta['resetUrl'] ?? null),
            ]),
        ]);

        if ($userId) {
            $this->attachEstimateToUser($userId, $estimateId, $currentMeta['locationId'] ?? null);
        }

        return ['ok' => true];
    }

    /**
     * @return array<string, mixed>
     */
    private function getDashboardForUser(int $userId): array
    {
        $estimateIds = get_user_meta($userId, 'ca_estimate_ids', true);
        if (!is_array($estimateIds)) {
            $estimateIds = array_filter([$estimateIds]);
        }

        $locations = get_user_meta($userId, 'ca_estimate_locations', true);
        if (!is_array($locations)) {
            $locations = [];
        }

        $items = [];
        foreach (array_unique($estimateIds) as $estimateId) {
            if (!$estimateId) {
                continue;
            }

            $locationId = $locations[$estimateId] ?? '';
            $status     = $this->getStatus($estimateId, $locationId);
            if (is_wp_error($status)) {
                continue;
            }

            $items[] = array_merge($status, [
                'estimateId' => $estimateId,
                'locationId' => $locationId,
            ]);
        }

        return $items;
    }

    /**
     * @return array<string, mixed>
     */
    private function getMeta(string $estimateId): array
    {
        $stored = get_option(self::OPTION_PREFIX . $estimateId, '{}');
        $decoded = json_decode($stored, true);
        if (!is_array($decoded)) {
            return [];
        }
        return $decoded;
    }

    private function updateMeta(string $estimateId, array $changes): void
    {
        $current = $this->getMeta($estimateId);
        $merged  = array_merge($current, $changes);
        update_option(self::OPTION_PREFIX . $estimateId, wp_json_encode($merged), false);
    }

    public function validateInviteToken(string $estimateId, string $token): bool
    {
        if (!$estimateId || !$token) {
            return false;
        }

        $accountToken = $this->getMeta($estimateId)['account']['inviteToken'] ?? null;

        return is_string($accountToken) && hash_equals($accountToken, $token);
    }

    private function sendPortalInvite(string $email, string $name, string $portalUrl, int $userId, bool $isResend): ?string
    {
        if (!$email || !$userId) {
            return null;
        }

        $user = get_user_by('id', $userId);
        if (!$user) {
            return null;
        }

        $subject = $isResend
            ? __('CheapAlarms portal invite (resent)', 'cheapalarms')
            : __('Your CheapAlarms portal is ready', 'cheapalarms');

        $key = get_password_reset_key($user);
        $resetUrl = null;
        if (!is_wp_error($key)) {
            $resetUrl = add_query_arg(
                [
                    'action' => 'rp',
                    'key'    => $key,
                    'login'  => rawurlencode($user->user_login),
                ],
                wp_login_url()
            );
        }

        $headers  = ['Content-Type: text/html; charset=UTF-8'];
        $greeting = sprintf(__('Hi %s,', 'cheapalarms'), $name);

        $body  = '<p>' . esc_html($greeting) . '</p>';
        $body .= '<p>' . esc_html(__('We have prepared your CheapAlarms portal. Use the secure links below to access your estimate and manage your installation.', 'cheapalarms')) . '</p>';
        $body .= '<p><a href="' . esc_url($portalUrl) . '">' . esc_html(__('Open your portal', 'cheapalarms')) . '</a></p>';

        if ($resetUrl) {
            $body .= '<p><a href="' . esc_url($resetUrl) . '">' . esc_html(__('Set or reset your password', 'cheapalarms')) . '</a></p>';
        } else {
            $body .= '<p>' . esc_html(__('If you need to reset your password, use the "Forgot password?" link on the login page.', 'cheapalarms')) . '</p>';
        }

        $body .= '<p>' . esc_html(__('This invite link remains active for 7 days. If it expires, contact us and we will resend it.', 'cheapalarms')) . '</p>';
        $body .= '<p>' . esc_html(__('Thanks,', 'cheapalarms')) . '<br />' . esc_html(__('CheapAlarms Team', 'cheapalarms')) . '</p>';

        wp_mail($email, $subject, $body, $headers);

        $this->logger->info('Portal invite email sent', [
            'email'    => $email,
            'userId'   => $userId,
            'resend'   => $isResend,
            'resetUrl' => $resetUrl,
        ]);

        return $resetUrl;
    }

    private function attachEstimateToUser(int $userId, string $estimateId, ?string $locationId = null): void
    {
        $existing = get_user_meta($userId, 'ca_estimate_ids', true);
        if (!is_array($existing)) {
            $existing = [];
        }
        if (!in_array($estimateId, $existing, true)) {
            $existing[] = $estimateId;
        }
        update_user_meta($userId, 'ca_estimate_ids', array_values(array_unique($existing)));
        update_user_meta($userId, 'ca_estimate_id', $estimateId);

        if ($locationId) {
            $locations = get_user_meta($userId, 'ca_estimate_locations', true);
            if (!is_array($locations)) {
                $locations = [];
            }
            $locations[$estimateId] = $locationId;
            update_user_meta($userId, 'ca_estimate_locations', $locations);
        }
    }
}


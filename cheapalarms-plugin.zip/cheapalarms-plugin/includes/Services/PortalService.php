<?php

namespace CheapAlarms\Plugin\Services;

use WP_Error;

use function add_query_arg;
use function apply_filters;
use function current_time;
use function esc_html;
use function esc_url;
use function email_exists;
use function get_option;
use function get_password_reset_key;
use function get_user_by;
use function home_url;
use function is_wp_error;
use function sanitize_email;
use function sanitize_text_field;
use function update_option;
use function update_user_meta;
use function wp_create_user;
use function wp_generate_password;
use function wp_mail;
use function wp_login_url;
use function wp_update_user;

class PortalService
{
    private const OPTION_PREFIX = 'ca_portal_meta_';

    public function __construct(
        private EstimateService $estimateService,
        private Logger $logger
    ) {
    }

    private function generateToken(): string
    {
        return wp_generate_password(48, false, false);
    }

    private function resolvePortalUrl(string $estimateId, ?string $token = null): string
    {
        $base = apply_filters('cheapalarms_portal_base_url', home_url('/portal'));
        $args = ['estimateId' => $estimateId];
        if ($token) {
            $args['inviteToken'] = $token;
        }

        return add_query_arg($args, $base);
    }

    /**
     * @return array|WP_Error
     */
    public function getStatus(string $estimateId, string $locationId)
    {
        $estimate = $this->estimateService->getEstimate([
            'estimateId' => $estimateId,
            'locationId' => $locationId,
        ]);
        if (is_wp_error($estimate)) {
            return $estimate;
        }

        $meta = $this->getMeta($estimateId);

        $quoteStatus = $meta['quote'] ?? [];
        if (empty($quoteStatus)) {
            $quoteStatus = [
                'status'      => ($estimate['status'] ?? '') === 'accepted' ? 'accepted' : 'pending',
                'statusLabel' => ($estimate['status'] ?? '') === 'accepted' ? 'Accepted' : 'Awaiting approval',
                'number'      => $estimate['estimateNumber'] ?? $estimate['estimateId'],
                'acceptedAt'  => null,
                'canAccept'   => ($estimate['status'] ?? '') !== 'accepted',
            ];
        }

        $defaultAccount = [
            'status'      => 'pending',
            'statusLabel' => 'Invite pending',
            'lastInviteAt'=> null,
            'canResend'   => true,
            'portalUrl'   => null,
            'inviteToken' => null,
            'expiresAt'   => null,
            'userId'      => null,
        ];

        return [
            'quote'        => $quoteStatus,
            'photos'       => $meta['photos'] ?? ['total' => 0, 'required' => 6, 'missingCount' => 6, 'items' => []],
            'installation' => $meta['installation'] ?? ['status' => 'pending', 'statusLabel' => 'Not scheduled', 'message' => null, 'canSchedule' => $quoteStatus['status'] === 'accepted'],
            'documents'    => $meta['documents'] ?? [],
            'account'      => array_merge($defaultAccount, $meta['account'] ?? []),
        ];
    }

    /**
     * @return array|WP_Error
     */
    public function acceptEstimate(string $estimateId, string $locationId)
    {
        $status = [
            'status'      => 'accepted',
            'statusLabel' => 'Accepted',
            'acceptedAt'  => current_time('mysql'),
            'canAccept'   => false,
        ];

        $this->updateMeta($estimateId, ['quote' => $status]);

        return ['ok' => true, 'quote' => $status];
    }

    /**
     * @return array|WP_Error
     */
    public function provisionAccount(string $estimateId, array $contact)
    {
        $email = sanitize_email($contact['email'] ?? '');
        if (!$email) {
            return new WP_Error('missing_contact', __('Contact email is required to create an account.', 'cheapalarms'), ['status' => 400]);
        }

        $firstName = sanitize_text_field($contact['firstName'] ?? $contact['name'] ?? '');
        $lastName  = sanitize_text_field($contact['lastName'] ?? '');

        $userId = email_exists($email);
        $password = null;
        if (!$userId) {
            $password = wp_generate_password(20);
            $userId = wp_create_user($email, $password, $email);
            if (is_wp_error($userId)) {
                return $userId;
            }
            wp_update_user([
                'ID'         => $userId,
                'first_name' => $firstName,
                'last_name'  => $lastName,
            ]);
        }

        wp_update_user(['ID' => $userId, 'role' => 'customer']);
        update_user_meta($userId, 'ca_estimate_id', $estimateId);

        $token     = $this->generateToken();
        $expiresAt = current_time('timestamp') + DAY_IN_SECONDS * 7;
        $portalUrl = $this->resolvePortalUrl($estimateId, $token);

        $accountMeta = [
            'status'      => 'active',
            'statusLabel' => 'Account active',
            'lastInviteAt'=> current_time('mysql'),
            'canResend'   => true,
            'portalUrl'   => $portalUrl,
            'inviteToken' => $token,
            'expiresAt'   => gmdate('c', $expiresAt),
            'userId'      => (int) $userId,
        ];

        $this->updateMeta($estimateId, ['account' => $accountMeta]);

        $displayName = sanitize_text_field($firstName ?: ($contact['name'] ?? 'customer'));

        $this->sendPortalInvite(
            $email,
            $displayName,
            $portalUrl,
            (int) $userId,
            false
        );

        $this->logger->info('Portal account provisioned', [
            'estimateId' => $estimateId,
            'userId'     => $userId,
        ]);

        return [
            'ok'      => true,
            'userId'  => $userId,
            'account' => $accountMeta,
        ];
    }

    /**
     * @return array|WP_Error
     */
    public function resendInvite(string $estimateId, array $contact)
    {
        $email = sanitize_email($contact['email'] ?? '');
        if (!$email) {
            return new WP_Error('missing_contact', __('Contact email is required to resend invite.', 'cheapalarms'), ['status' => 400]);
        }

        $currentMeta = $this->getMeta($estimateId)['account'] ?? [];
        $token       = $currentMeta['inviteToken'] ?? $this->generateToken();
        $portalLink  = $this->resolvePortalUrl($estimateId, $token);

        $userId      = isset($currentMeta['userId']) ? (int) $currentMeta['userId'] : (int) email_exists($email);
        $contactName = sanitize_text_field($contact['name'] ?? $contact['firstName'] ?? 'customer');

        $this->sendPortalInvite(
            $email,
            $contactName,
            $portalLink,
            $userId,
            true
        );

        $this->updateMeta($estimateId, [
            'account' => array_merge($currentMeta, [
                'lastInviteAt' => current_time('mysql'),
                'status'       => $currentMeta['status'] ?? 'pending',
                'statusLabel'  => ($currentMeta['status'] ?? '') === 'active' ? 'Account active' : 'Invite sent',
                'canResend'    => true,
                'inviteToken'  => $token,
                'portalUrl'    => $portalLink,
                'expiresAt'    => gmdate('c', current_time('timestamp') + DAY_IN_SECONDS * 7),
                'userId'       => $userId ?: ($currentMeta['userId'] ?? null),
            ]),
        ]);

        return ['ok' => true];
    }

    /**
     * @return array<string, mixed>
     */
    private function getMeta(string $estimateId): array
    {
        $stored = get_option(self::OPTION_PREFIX . $estimateId, '{}');
        $decoded = json_decode($stored, true);
        if (!is_array($decoded)) {
            return [];
        }
        return $decoded;
    }

    private function updateMeta(string $estimateId, array $changes): void
    {
        $current = $this->getMeta($estimateId);
        $merged  = array_merge($current, $changes);
        update_option(self::OPTION_PREFIX . $estimateId, wp_json_encode($merged), false);
    }

    private function sendPortalInvite(string $email, string $name, string $portalUrl, int $userId, bool $isResend): void
    {
        if (!$email || !$userId) {
            return;
        }

        $user = get_user_by('id', $userId);
        if (!$user) {
            return;
        }

        $subject = $isResend
            ? __('CheapAlarms portal invite (resent)', 'cheapalarms')
            : __('Your CheapAlarms portal is ready', 'cheapalarms');

        $key = get_password_reset_key($user);
        $resetUrl = null;
        if (!is_wp_error($key)) {
            $resetUrl = add_query_arg(
                [
                    'action' => 'rp',
                    'key'    => $key,
                    'login'  => rawurlencode($user->user_login),
                ],
                wp_login_url()
            );
        }

        $headers  = ['Content-Type: text/html; charset=UTF-8'];
        $greeting = sprintf(__('Hi %s,', 'cheapalarms'), $name);

        $body  = '<p>' . esc_html($greeting) . '</p>';
        $body .= '<p>' . esc_html(__('We have prepared your CheapAlarms portal. Use the secure links below to access your estimate and manage your installation.', 'cheapalarms')) . '</p>';
        $body .= '<p><a href="' . esc_url($portalUrl) . '">' . esc_html(__('Open your portal', 'cheapalarms')) . '</a></p>';

        if ($resetUrl) {
            $body .= '<p><a href="' . esc_url($resetUrl) . '">' . esc_html(__('Set or reset your password', 'cheapalarms')) . '</a></p>';
        } else {
            $body .= '<p>' . esc_html(__('If you need to reset your password, use the "Forgot password?" link on the login page.', 'cheapalarms')) . '</p>';
        }

        $body .= '<p>' . esc_html(__('This invite link remains active for 7 days. If it expires, contact us and we will resend it.', 'cheapalarms')) . '</p>';
        $body .= '<p>' . esc_html(__('Thanks,', 'cheapalarms')) . '<br />' . esc_html(__('CheapAlarms Team', 'cheapalarms')) . '</p>';

        wp_mail($email, $subject, $body, $headers);

        $this->logger->info('Portal invite email sent', [
            'email'  => $email,
            'userId' => $userId,
            'resend' => $isResend,
        ]);
    }
}

